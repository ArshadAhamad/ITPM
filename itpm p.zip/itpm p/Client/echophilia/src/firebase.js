// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyCf9sLlWopENHK1Y3BoQYDfF1tD2NLT8zM",
  authDomain: "echophilia-421dd.firebaseapp.com",
  projectId: "echophilia-421dd",
  storageBucket: "echophilia-421dd.appspot.com",
  messagingSenderId: "93870004930",
  appId: "1:93870004930:web:56c42fd873950aabb2395b",
  measurementId: "G-66GV9M2WD5"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
const auth = getAuth();
const provider = new GoogleAuthProvider();

export { auth, provider };
