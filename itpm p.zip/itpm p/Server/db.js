const mongoose = require("mongoose");

const url =
  "mongodb+srv://<hansaz>:<aA4fYTLIVcOST2NW>@cluster0.vzx1e.mongodb.net/echophilia?retryWrites=true&w=majority";

module.exports.connect = () => {
  mongoose
    .connect(url, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    })
    .then(() => {
      console.log("MongoDB connected successfully");
    })
    .catch((error) => console.log("Error: ", error));
};
