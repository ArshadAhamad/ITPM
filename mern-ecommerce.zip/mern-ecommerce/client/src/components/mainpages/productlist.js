import React, { useEffect } from 'react'
import { LinkContainer } from 'react-router-bootstrap'
import { Table, Button } from 'react-bootstrap'
import { useDispatch, useSelector } from 'react-redux'
import Loader from '../components/LoadMore'
import { listproducts } from '../actions/orderActions'
import { PDFDownloadLink } from '@react-pdf/renderer'
import PDFFile from '../components/PDFFile'
import { Page, Text, Document,View, StyleSheet } from "@react-pdf/renderer";
import PropTypes from 'prop-types'

const ProductListScreen = ({ history }) => {
  const dispatch = useDispatch()

  const ProductList = useSelector((state) => state.ProductList)
  const { loading, error, products } = ProductList

  console.log("products :",products);

  const userLogin = useSelector((state) => state.userLogin)
  const { userInfo } = userLogin
  
  const styles = StyleSheet.create({
    table: {
      width: '100%',
    },
    row: {
      display: 'flex',
      flexDirection: 'row',
      borderTop: '1px solid #EEE',
      paddingTop: 8,
      paddingBottom: 8,
    },
    header: {
      borderTop: 'none',
      fontSize: 15,
    },
    bold: {
      fontWeight: 'bold',
    },
    row1: {
      width: '15%',
    },
    row2: {
      width: '15%',
    },
    row3: {
      width: '15%',
    },
    row4: {
      width: '15%',
    },
    row5: {
      width: '15%',
    },
    text:{
      fontSize:12,
    }

  })
  
  const PDFFile01 = ({ data, maximumDays })=>{
    return(
      <>
       <Document>
       <Page style={styles.body}>
       <View style={styles.table}>

      <View style={[styles.row, styles.bold, styles.header]}>
        <Text style={styles.row1}>ProductID</Text>
        <Text style={styles.row2}>ProductName</Text>
        <Text style={styles.row3}>SellerName</Text>
        <Text style={styles.row4}>Availability</Text>
      </View>
        
        <Text style={styles.text}> 
          <div> 
              {products? products.map((item)=>(
                <tr>
                <Text style={styles.row1} > <td>{item._id}</td></Text>
                <Text style={styles.row1} ><td>{item.product && item.product.name}</td></Text>
                <Text style={styles.row1} ><td>{item.user && item.user.name}</td></Text>
                <Text style={styles.row1} >  <td>{item.availability}</td> </Text>
                </tr>
              )) :<h1>Cancel</h1>}
          </div>
        </Text>
    </View>
      </Page>
      </Document>
      
      </>
    )
  }

  useEffect(() => {
    if (userInfo && userInfo.isAdmin) {
      dispatch(listproducts())
    } else {
      history.push('/login')
    }
  }, [dispatch, history, userInfo])

  return (
    <>
      <h1>products</h1>
      <PDFDownloadLink document={<PDFFile01/>} fileName="products">
        {({loading}) => (loading ? <button> loading document</button> : <button> Download</button> )}
      </PDFDownloadLink>
      {loading ? (
        <Loader />
      ) : error ? (
        <Message variant='danger'>{error}</Message>
      ) : (
        <Table striped bordered hover responsive className='table-sm'>
          {/* <PDFFile/> */}
          <thead>
            <tr>
              <th>Name</th>
              <th>ID</th>
              <th>Name</th>
              <th>Availability</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {products.map((product) => (
              <tr key={product._id}>
                <td>{product._id}</td>
                <td>{product.products && product.products.name}</td>
                <td>{product.user && product.user.name}</td>
                <td>{product.Availability}</td>
               
                <td>
                  <LinkContainer to={`/product/${product._id}`}>
                    <Button variant='light' className='btn-sm'>
                      Details
                    </Button>
                  </LinkContainer>
                </td>
              </tr>
            ))}
          </tbody>
        </Table>
      
      )}
    </>
  )
}

ProductListScreen.propTypes = {
  data: PropTypes.array.isRequired,
  maximumDays: PropTypes.number.isRequired,
}
export default ProductListScreen
